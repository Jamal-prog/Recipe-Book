import requests
RECIPE_URL = "http://www.recipepuppy.com/api/?i=onions,garlic&q=omelet&p=3 "

response = requests.get(RECIPE_URL)
json= response.json()
title = json["results"][0]["title"]
title = json["results"][1]["title"]
ingredients = json["results"][1]["ingredients"]
print(title)
print(ingredients)
while (1<2):
  print("Enter 1 to look up meal, Enter 2 to look up ingredients")
  choice = int(input())
  if choice == 1:
    print("Enter a meal")
    y = input()
    RECIPE_URL = "http://www.recipepuppy.com/api/?q={} ".format(y)
    response = requests.get(RECIPE_URL)
    json= response.json()
    title = json["results"][0]["title"]
    title1 = json["results"][1]["title"]
    ingredients = json["results"][0]["ingredients"]
    ingredients1 = json["results"][1]["ingredients"]
    print(title) 
    print (ingredients)
    print(title1)
    print (ingredients1)

  else:
    print("Enter an ingredients")
    x = input()
    RECIPE_URL = "http://www.recipepuppy.com/api/?i={} ".format(x)
    response = requests.get(RECIPE_URL)
    json= response.json()
    title = json["results"][0]["title"]
    title1 = json["results"][1]["title"]
    ingredients = json["results"][0]["ingredients"]
    ingredients1 = json["results"][1]["ingredients"]
    print(title)
    print (ingredients)
    print(title1)
    print (ingredients1)
 